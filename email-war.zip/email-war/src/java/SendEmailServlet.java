import java.io.IOException;
import java.io.PrintWriter;
import java.util.Properties;
import java.util.logging.Logger;
import javax.mail.*;
import javax.mail.internet.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/SendEmailServlet")
public class SendEmailServlet extends HttpServlet {
    private static final Logger logger = Logger.getLogger(SendEmailServlet.class.getName()); // Use WebLogic logs

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String smtpHost = request.getParameter("smtpHost");
        String smtpPort = request.getParameter("smtpPort");
        String senderEmail = request.getParameter("senderEmail");
        String senderName = request.getParameter("senderName");
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String recipient = request.getParameter("recipient");
        String subject = request.getParameter("subject");
        String messageText = request.getParameter("message");

        // Setup mail properties
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", smtpHost);
        props.put("mail.smtp.port", smtpPort);
        props.put("mail.smtp.debug", "true"); // Enable SMTP debug

        // Create session with debugging
        Session session = Session.getInstance(props, new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
        });

        // Redirect debug logs to WebLogic logs
        session.setDebug(true);
        session.setDebugOut(System.out); // Redirects to standard output (WebLogic should capture this)

        try {
            // Create email message
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(senderEmail, senderName));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipient));
            message.setSubject(subject);
            message.setText(messageText);

            // Log debug before sending
            logger.info("Sending email to: " + recipient);
            logger.info("SMTP Host: " + smtpHost + ", Port: " + smtpPort);
            logger.info("Sender: " + senderEmail + " (" + senderName + ")");

            // Send email
            Transport.send(message);
            logger.info("Email sent successfully!");

            // Response
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            out.println("<h3>Email Sent Successfully</h3>");
        } catch (MessagingException e) {
            // Log error details
            logger.severe("Email sending failed: " + e.getMessage());
            e.printStackTrace();

            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            out.println("<h3>Error: " + e.getMessage() + "</h3>");
        }
    }
}
